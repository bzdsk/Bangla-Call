package com.banglacall.app.activities;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;
import com.banglacall.app.databinding.ActivityCallBinding;
import com.banglacall.app.services.SipService;

public class CallActivity extends AppCompatActivity {

    private ActivityCallBinding binding;
    private SipService sipService;
    private boolean isBound = false;
    private String callNumber;
    private Handler timerHandler = new Handler(Looper.getMainLooper());
    private int elapsedSeconds = 0;
    private boolean callConnected = false;

    private Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (callConnected) {
                elapsedSeconds++;
                binding.tvCallDuration.setText(formatTime(elapsedSeconds));
                timerHandler.postDelayed(this, 1000);
            }
        }
    };

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            SipService.LocalBinder binder = (SipService.LocalBinder) service;
            sipService = binder.getService();
            isBound = true;
            startCallMonitor();
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);

        binding = ActivityCallBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        callNumber = getIntent().getStringExtra("number");
        boolean isIncoming = getIntent().getBooleanExtra("isIncoming", false);

        binding.tvCallNumber.setText(callNumber != null ? callNumber : "অজানা");
        binding.tvCallStatus.setText(isIncoming ? "ইনকামিং কল" : "কল করা হচ্ছে...");

        Intent serviceIntent = new Intent(this, SipService.class);
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);

        setupButtons();
    }

    private void setupButtons() {
        // End call
        binding.btnEndCall.setOnClickListener(v -> {
            if (isBound && sipService != null) sipService.hangUp();
            finish();
        });

        // Mute
        binding.btnMute.setOnClickListener(v -> {
            if (isBound && sipService != null) {
                boolean muted = sipService.toggleMute();
                binding.btnMute.setAlpha(muted ? 0.5f : 1.0f);
                binding.tvMuteLabel.setText(muted ? "আনমিউট" : "মিউট");
            }
        });

        // Speaker
        binding.btnSpeaker.setOnClickListener(v -> {
            if (isBound && sipService != null) {
                boolean speaker = sipService.toggleSpeaker();
                binding.btnSpeaker.setAlpha(speaker ? 1.0f : 0.5f);
                binding.tvSpeakerLabel.setText(speaker ? "স্পিকার অন" : "স্পিকার অফ");
            }
        });
    }

    private void startCallMonitor() {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (isBound && sipService != null) {
                    SipService.CallState state = sipService.getCurrentCallState();
                    if (state == SipService.CallState.CONNECTED && !callConnected) {
                        callConnected = true;
                        binding.tvCallStatus.setText("কল সংযুক্ত");
                        timerHandler.post(timerRunnable);
                    } else if (state == SipService.CallState.ENDED) {
                        finish();
                        return;
                    }
                    handler.postDelayed(this, 500);
                }
            }
        });
    }

    private String formatTime(int secs) {
        int m = secs / 60;
        int s = secs % 60;
        return String.format("%02d:%02d", m, s);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timerHandler.removeCallbacks(timerRunnable);
        if (isBound) { unbindService(serviceConnection); isBound = false; }
    }
}
