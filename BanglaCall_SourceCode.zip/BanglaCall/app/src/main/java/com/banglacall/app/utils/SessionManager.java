package com.banglacall.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {

    private static final String PREF_NAME = "bangla_call_session";
    private static final String KEY_IS_LOGGED_IN = "is_logged_in";
    private static final String KEY_SIP_SERVER   = "sip_server";
    private static final String KEY_USERNAME      = "username";
    private static final String KEY_PASSWORD      = "password";
    private static final String KEY_PORT          = "port";

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;

    public SessionManager(Context context) {
        prefs  = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void saveAccount(SipAccountConfig config) {
        editor.putBoolean(KEY_IS_LOGGED_IN, true);
        editor.putString(KEY_SIP_SERVER, config.getSipServer());
        editor.putString(KEY_USERNAME,   config.getUsername());
        editor.putString(KEY_PASSWORD,   config.getPassword());
        editor.putString(KEY_PORT,       config.getPort());
        editor.apply();
    }

    public SipAccountConfig getAccount() {
        if (!isLoggedIn()) return null;
        return new SipAccountConfig(
            prefs.getString(KEY_SIP_SERVER, ""),
            prefs.getString(KEY_USERNAME,   ""),
            prefs.getString(KEY_PASSWORD,   ""),
            prefs.getString(KEY_PORT,       "5060")
        );
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false);
    }

    public void logout() {
        editor.clear();
        editor.apply();
    }
}
