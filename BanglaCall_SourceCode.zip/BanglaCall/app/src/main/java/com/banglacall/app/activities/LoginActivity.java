package com.banglacall.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.banglacall.app.databinding.ActivityLoginBinding;
import com.banglacall.app.utils.SessionManager;
import com.banglacall.app.utils.SipAccountConfig;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;
    private SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sessionManager = new SessionManager(this);

        binding.btnLogin.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        String sipServer  = binding.etSipServer.getText().toString().trim();
        String username   = binding.etUsername.getText().toString().trim();
        String password   = binding.etPassword.getText().toString().trim();
        String port       = binding.etPort.getText().toString().trim();

        if (TextUtils.isEmpty(sipServer)) {
            binding.etSipServer.setError("SIP Server দিন");
            return;
        }
        if (TextUtils.isEmpty(username)) {
            binding.etUsername.setError("Username দিন");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            binding.etPassword.setError("Password দিন");
            return;
        }

        if (TextUtils.isEmpty(port)) port = "5060";

        binding.btnLogin.setEnabled(false);
        binding.progressBar.setVisibility(View.VISIBLE);

        // Save credentials
        SipAccountConfig config = new SipAccountConfig(sipServer, username, password, port);
        sessionManager.saveAccount(config);

        // Navigate to Main
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
