package com.banglacall.app.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.ContextCompat;
import com.banglacall.app.services.SipService;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            SessionManager session = new SessionManager(context);
            if (session.isLoggedIn()) {
                Intent serviceIntent = new Intent(context, SipService.class);
                ContextCompat.startForegroundService(context, serviceIntent);
            }
        }
    }
}
