package com.banglacall.app.utils;

public class SipAccountConfig {
    private String sipServer;
    private String username;
    private String password;
    private String port;

    public SipAccountConfig(String sipServer, String username, String password, String port) {
        this.sipServer = sipServer;
        this.username  = username;
        this.password  = password;
        this.port      = port;
    }

    public String getSipServer() { return sipServer; }
    public String getUsername()  { return username; }
    public String getPassword()  { return password; }
    public String getPort()      { return port; }

    public String getSipUri() {
        return "sip:" + username + "@" + sipServer + ":" + port;
    }
}
