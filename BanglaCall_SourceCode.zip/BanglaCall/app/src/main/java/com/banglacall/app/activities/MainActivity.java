package com.banglacall.app.activities;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.banglacall.app.databinding.ActivityMainBinding;
import com.banglacall.app.services.SipService;
import com.banglacall.app.utils.SessionManager;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    private SipService sipService;
    private boolean isBound = false;
    private StringBuilder dialedNumber = new StringBuilder();
    private static final int PERMISSION_REQUEST_CODE = 100;
    private SessionManager sessionManager;

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            SipService.LocalBinder binder = (SipService.LocalBinder) service;
            sipService = binder.getService();
            isBound = true;
            updateRegistrationStatus();
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        sessionManager = new SessionManager(this);
        setupDialpad();
        setupButtons();
        checkAndRequestPermissions();
        startSipService();
    }

    private void startSipService() {
        Intent serviceIntent = new Intent(this, SipService.class);
        ContextCompat.startForegroundService(this, serviceIntent);
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);
    }

    private void checkAndRequestPermissions() {
        String[] permissions = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_PHONE_STATE
        };
        boolean allGranted = true;
        for (String perm : permissions) {
            if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }
        if (!allGranted) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }
    }

    private void setupDialpad() {
        int[] numIds = {
            com.banglacall.app.R.id.btn0, com.banglacall.app.R.id.btn1, com.banglacall.app.R.id.btn2,
            com.banglacall.app.R.id.btn3, com.banglacall.app.R.id.btn4, com.banglacall.app.R.id.btn5,
            com.banglacall.app.R.id.btn6, com.banglacall.app.R.id.btn7, com.banglacall.app.R.id.btn8,
            com.banglacall.app.R.id.btn9, com.banglacall.app.R.id.btnStar, com.banglacall.app.R.id.btnHash
        };
        String[] numValues = {"0","1","2","3","4","5","6","7","8","9","*","#"};

        for (int i = 0; i < numIds.length; i++) {
            final String digit = numValues[i];
            View btn = binding.getRoot().findViewById(numIds[i]);
            if (btn != null) {
                btn.setOnClickListener(v -> {
                    dialedNumber.append(digit);
                    binding.tvDialNumber.setText(dialedNumber.toString());
                });
            }
        }
    }

    private void setupButtons() {
        // Backspace
        binding.btnBackspace.setOnClickListener(v -> {
            if (dialedNumber.length() > 0) {
                dialedNumber.deleteCharAt(dialedNumber.length() - 1);
                binding.tvDialNumber.setText(dialedNumber.toString());
            }
        });

        binding.btnBackspace.setOnLongClickListener(v -> {
            dialedNumber.setLength(0);
            binding.tvDialNumber.setText("");
            return true;
        });

        // Call button
        binding.btnCall.setOnClickListener(v -> {
            String number = dialedNumber.toString().trim();
            if (number.isEmpty()) {
                Toast.makeText(this, "নম্বর দিন", Toast.LENGTH_SHORT).show();
                return;
            }
            if (isBound && sipService != null) {
                sipService.makeCall(number);
                Intent callIntent = new Intent(this, CallActivity.class);
                callIntent.putExtra("number", number);
                callIntent.putExtra("isIncoming", false);
                startActivity(callIntent);
            } else {
                Toast.makeText(this, "SIP Service সংযুক্ত নয়", Toast.LENGTH_SHORT).show();
            }
        });

        // Logout
        binding.btnLogout.setOnClickListener(v -> {
            sessionManager.logout();
            if (isBound && sipService != null) sipService.unregister();
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    private void updateRegistrationStatus() {
        if (isBound && sipService != null) {
            boolean registered = sipService.isRegistered();
            binding.tvStatus.setText(registered ? "✓ নিবন্ধিত" : "● নিবন্ধন হচ্ছে...");
            binding.tvStatus.setTextColor(registered ?
                getColor(com.banglacall.app.R.color.green_status) :
                getColor(com.banglacall.app.R.color.yellow_status));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateRegistrationStatus();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isBound) {
            unbindService(serviceConnection);
            isBound = false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "মাইক্রোফোন অনুমতি দেওয়া প্রয়োজন", Toast.LENGTH_LONG).show();
                    break;
                }
            }
        }
    }
}
