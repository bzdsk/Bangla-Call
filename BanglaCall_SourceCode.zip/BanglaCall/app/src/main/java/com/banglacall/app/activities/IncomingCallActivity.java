package com.banglacall.app.activities;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;
import com.banglacall.app.databinding.ActivityIncomingCallBinding;
import com.banglacall.app.services.SipService;

public class IncomingCallActivity extends AppCompatActivity {

    private ActivityIncomingCallBinding binding;
    private SipService sipService;
    private boolean isBound = false;
    private String callerNumber;

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            SipService.LocalBinder binder = (SipService.LocalBinder) service;
            sipService = binder.getService();
            isBound = true;
        }
        @Override
        public void onServiceDisconnected(ComponentName name) { isBound = false; }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        binding = ActivityIncomingCallBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        callerNumber = getIntent().getStringExtra("caller");
        binding.tvCallerNumber.setText(callerNumber != null ? callerNumber : "অজানা নম্বর");

        Intent serviceIntent = new Intent(this, SipService.class);
        bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE);

        // Accept
        binding.btnAccept.setOnClickListener(v -> {
            if (isBound && sipService != null) sipService.acceptCall();
            Intent callIntent = new Intent(this, CallActivity.class);
            callIntent.putExtra("number", callerNumber);
            callIntent.putExtra("isIncoming", true);
            startActivity(callIntent);
            finish();
        });

        // Reject
        binding.btnReject.setOnClickListener(v -> {
            if (isBound && sipService != null) sipService.rejectCall();
            finish();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isBound) { unbindService(serviceConnection); isBound = false; }
    }
}
