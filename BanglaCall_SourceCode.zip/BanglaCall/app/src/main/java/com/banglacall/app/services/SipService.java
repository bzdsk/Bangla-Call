package com.banglacall.app.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.banglacall.app.R;
import com.banglacall.app.activities.MainActivity;
import com.banglacall.app.utils.SessionManager;
import com.banglacall.app.utils.SipAccountConfig;

/**
 * SipService handles SIP registration, outgoing calls, incoming calls,
 * mute, and speaker toggle via the Android SipManager API.
 *
 * NOTE: Android's built-in SipManager is deprecated in API 31+.
 * For production, replace SipManager calls with MjSip / Linphone SDK.
 * This file provides the full architecture; swap the SIP engine as needed.
 */
public class SipService extends Service {

    private static final String TAG = "SipService";
    private static final String CHANNEL_ID = "bangla_call_sip";
    private static final int NOTIFICATION_ID = 1;

    public enum CallState { IDLE, RINGING, CONNECTED, ENDED }

    private final IBinder binder = new LocalBinder();
    private CallState currentCallState = CallState.IDLE;
    private boolean registered = false;
    private boolean muted = false;
    private boolean speakerOn = false;
    private AudioManager audioManager;
    private SessionManager sessionManager;

    // ─── Binder ──────────────────────────────────────────────────
    public class LocalBinder extends Binder {
        public SipService getService() { return SipService.this; }
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    // ─── Lifecycle ────────────────────────────────────────────────
    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        sessionManager = new SessionManager(this);
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification("Bangla Call চলছে..."));
        registerSip();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregister();
    }

    // ─── SIP Registration ─────────────────────────────────────────
    private void registerSip() {
        SipAccountConfig config = sessionManager.getAccount();
        if (config == null) {
            Log.w(TAG, "No SIP account configured");
            return;
        }

        Log.d(TAG, "Registering SIP: " + config.getUsername() + "@" + config.getSipServer());

        /*
         * ── Real SIP Registration (MjSip / Linphone) ──
         *
         * Example using MjSip (replace with actual library calls):
         *
         * SipStack stack = new SipStack(config.getSipServer(), config.getPort());
         * stack.register(config.getUsername(), config.getPassword(), new RegistrationListener() {
         *     @Override public void onRegistered() { registered = true; }
         *     @Override public void onFailed(String reason) { registered = false; }
         * });
         *
         * For Android built-in SipManager (API < 31):
         * SipProfile.Builder builder = new SipProfile.Builder(config.getUsername(), config.getSipServer());
         * builder.setPassword(config.getPassword());
         * builder.setPort(Integer.parseInt(config.getPort()));
         * SipProfile profile = builder.build();
         * sipManager.open(profile, pendingIntent, null);
         * sipManager.register(profile, 3600, listener);
         */

        // Simulate registered = true for UI testing
        registered = true;
        updateNotification("নিবন্ধিত: " + config.getUsername());
    }

    public void unregister() {
        registered = false;
        Log.d(TAG, "SIP unregistered");
    }

    // ─── Call Control ─────────────────────────────────────────────
    public void makeCall(String number) {
        Log.d(TAG, "Making call to: " + number);
        currentCallState = CallState.RINGING;
        updateNotification("কল চলছে: " + number);

        /*
         * Real SIP call:
         * SipAudioCall call = sipManager.makeAudioCall(localProfile.getUriString(),
         *     "sip:" + number + "@" + server, listener, 30);
         */
    }

    public void acceptCall() {
        Log.d(TAG, "Accepting incoming call");
        currentCallState = CallState.CONNECTED;

        /*
         * Real:
         * incomingCall.answerCall(30);
         * incomingCall.startAudio();
         */
    }

    public void rejectCall() {
        Log.d(TAG, "Rejecting incoming call");
        currentCallState = CallState.IDLE;

        /*
         * Real:
         * incomingCall.endCall();
         */
    }

    public void hangUp() {
        Log.d(TAG, "Hanging up");
        currentCallState = CallState.ENDED;
        muted = false;
        if (speakerOn) toggleSpeaker();
        updateNotification("নিবন্ধিত");

        /*
         * Real:
         * activeCall.endCall();
         * activeCall.close();
         */
    }

    // ─── Audio Controls ──────────────────────────────────────────
    public boolean toggleMute() {
        muted = !muted;
        if (audioManager != null) {
            audioManager.setMicrophoneMute(muted);
        }
        Log.d(TAG, "Mute: " + muted);
        return muted;
    }

    public boolean toggleSpeaker() {
        speakerOn = !speakerOn;
        if (audioManager != null) {
            audioManager.setSpeakerphoneOn(speakerOn);
        }
        Log.d(TAG, "Speaker: " + speakerOn);
        return speakerOn;
    }

    // ─── State Getters ───────────────────────────────────────────
    public boolean isRegistered()          { return registered; }
    public CallState getCurrentCallState() { return currentCallState; }
    public boolean isMuted()               { return muted; }
    public boolean isSpeakerOn()           { return speakerOn; }

    // ─── Notification ─────────────────────────────────────────────
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Bangla Call", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("SIP পরিষেবা চলছে");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String text) {
        Intent notifIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, notifIntent,
            PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Bangla Call")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_call_notification)
            .setContentIntent(pi)
            .setOngoing(true)
            .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(NOTIFICATION_ID, buildNotification(text));
    }
}
