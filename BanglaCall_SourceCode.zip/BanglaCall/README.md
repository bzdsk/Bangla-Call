# 📞 Bangla Call — Android VoIP App

**SIP-ভিত্তিক Android কলিং অ্যাপ — amarip.net এর জন্য তৈরি**

---

## 📁 প্রজেক্ট স্ট্রাকচার

```
BanglaCall/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/banglacall/app/
│       │   ├── activities/
│       │   │   ├── SplashActivity.java       ← স্প্ল্যাশ স্ক্রিন
│       │   │   ├── LoginActivity.java        ← SIP লগইন
│       │   │   ├── MainActivity.java         ← ডায়ালপ্যাড
│       │   │   ├── CallActivity.java         ← সক্রিয় কল স্ক্রিন
│       │   │   └── IncomingCallActivity.java ← ইনকামিং কল
│       │   ├── services/
│       │   │   └── SipService.java           ← SIP ব্যাকগ্রাউন্ড সার্ভিস
│       │   └── utils/
│       │       ├── SessionManager.java       ← লগইন সেশন
│       │       ├── SipAccountConfig.java     ← SIP কনফিগ
│       │       └── BootReceiver.java         ← ফোন চালু হলে অটো-শুরু
│       └── res/
│           ├── layout/                       ← সব স্ক্রিনের XML
│           ├── drawable/                     ← ব্যাকগ্রাউন্ড, আইকন
│           └── values/                       ← colors, strings, themes
├── build.gradle
└── settings.gradle
```

---

## 🚀 Android Studio-তে কীভাবে খুলবেন

1. **Android Studio** খুলুন (Hedgehog বা নতুন)
2. **File → Open** → `BanglaCall` ফোল্ডার সিলেক্ট করুন
3. Gradle sync হওয়ার জন্য অপেক্ষা করুন
4. `app/build.gradle`-এ dependencies ঠিক আছে কিনা দেখুন

---

## 🔧 SIP লাইব্রেরি যোগ করুন (গুরুত্বপূর্ণ!)

এই প্রজেক্টে SIP ইঞ্জিন হিসেবে দুটি অপশন আছে:

### অপশন ১: MjSip (সহজ, ওপেন সোর্স)
`app/build.gradle`-এ এটি ইতিমধ্যে আছে:
```groovy
implementation 'com.github.luminlabsdev:android-sip-lib:1.0.2'
```

### অপশন ২: Linphone SDK (প্রফেশনাল, বেশি ফিচার)
```groovy
implementation 'org.linphone:linphone-sdk-android:5.3.+'
```
তারপর `SipService.java`-এ কমেন্ট করা Linphone কোড uncomment করুন।

---

## 📱 অ্যাপের স্ক্রিনগুলো

| স্ক্রিন | বিবরণ |
|---------|--------|
| Splash | লোগো সহ 2.5 সেকেন্ডের ওয়েলকাম স্ক্রিন |
| Login | SIP Server, Username, Password, Port দিয়ে লগইন |
| Dialer | ডায়ালপ্যাড, নম্বর দিখানো, কল বাটন |
| Call | সক্রিয় কল, টাইমার, মিউট, স্পিকার |
| Incoming | গ্রহণ/প্রত্যাখ্যান বাটন |

---

## ⚙️ SipService.java — কীভাবে রিয়েল SIP যোগ করবেন

`SipService.java`-এ `registerSip()` মেথডে কমেন্ট করা কোড দেখুন:

```java
// এটি uncomment করুন এবং আপনার SIP লাইব্রেরি দিয়ে পরিবর্তন করুন:
SipProfile.Builder builder = new SipProfile.Builder(username, sipServer);
builder.setPassword(password);
builder.setPort(Integer.parseInt(port));
SipProfile profile = builder.build();
sipManager.open(profile, pendingIntent, null);
sipManager.register(profile, 3600, listener);
```

---

## 🔑 amarip.net-এ লগইন

অ্যাপে এই তথ্য দিন:
- **SIP Server:** `amarip.net`
- **Username:** আপনার SIP extension নম্বর
- **Password:** আপনার SIP পাসওয়ার্ড
- **Port:** `5060` (ডিফল্ট)

---

## ✅ APK তৈরি করতে

```
Build → Generate Signed Bundle/APK → APK → Next
```
অথবা debug build:
```
Build → Build Bundle(s)/APK(s) → Build APK(s)
```

---

## 📋 প্রয়োজনীয় Permission

- `RECORD_AUDIO` — মাইক্রোফোন
- `USE_SIP` — SIP কল
- `INTERNET` — নেটওয়ার্ক
- `FOREGROUND_SERVICE` — ব্যাকগ্রাউন্ড সার্ভিস
- `RECEIVE_BOOT_COMPLETED` — ফোন চালু হলে অটো-শুরু

---

**তৈরি করেছে: Claude (Anthropic) — Bangla Call এর জন্য**
